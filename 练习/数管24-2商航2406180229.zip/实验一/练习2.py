class A:
    def __init__(self):
        self.v = 100


def guess_number():
    a = A()
    while True:
        try:
            guess_result = int(input("请猜一个数字："))
            if guess_result > a.v:
                print("大了")
            elif guess_result < a.v:
                print("小了")
            else:
                print("猜对了")
                break
        except ValueError:
            print("请输入有效的参数")


if __name__ == '__main__':
    guess_number()
