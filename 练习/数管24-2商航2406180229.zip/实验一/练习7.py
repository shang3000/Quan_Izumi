class Employee:
    def __init__(self, name, age, post, salary):
        self.name = name
        self.age = age
        self.post = post
        self.salary = salary

    def introduce(self):
        print(f"姓名：{self.name}，年龄：{self.age}，职称：{self.post}，基本工资：{self.salary}")


class Manager(Employee):
    def __init__(self, name, age, post, salary):
        super().__init__(name, age, post, salary)

    def introduce(self):
        actual_salary = self.salary * 3.3
        print(
            f"【公司经理】姓名：{self.name}，年龄：{self.age}，职称：{self.post}，基本工资：{self.salary}，工资系数：3.3，实际工资：{actual_salary:.2f}")


class DepartmentHead(Employee):
    def __init__(self, name, age, post, salary):
        super().__init__(name, age, post, salary)

    def introduce(self):
        actual_salary = self.salary * 2.1
        print(
            f"【部门主任】姓名：{self.name}，年龄：{self.age}，职称：{self.post}，基本工资：{self.salary}，工资系数：2.1，实际工资：{actual_salary:.2f}")


class Staff(Employee):
    def __init__(self, name, age, post, salary):
        super().__init__(name, age, post, salary)

    def introduce(self):
        actual_salary = self.salary * 1
        print(
            f"【普通员工】姓名：{self.name}，年龄：{self.age}，职称：{self.post}，基本工资：{self.salary}，工资系数：1，实际工资：{actual_salary:.2f}")


if __name__ == "__main__":
    manager = Manager("张总", 45, "公司经理", 20000)
    head = DepartmentHead("李主任", 38, "部门主任", 15000)
    staff = Staff("小王", 25, "普通员工", 8000)

    print("员工信息输出：")
    manager.introduce()
    head.introduce()
    staff.introduce()
