class Person:
    def __init__(self, name, age, job):
        self.name = name
        self.age = age
        self.job = job


def bubble_sort(person_list):
    arr = person_list.copy()
    n = len(arr)

    for i in range(n - 1):
        for j in range(n - 1 - i):
            if arr[j].age < arr[j + 1].age:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr


if __name__ == "__main__":
    person1 = Person("张三", 35, "工程师")
    person2 = Person("李四", 28, "设计师")
    person3 = Person("王五", 42, "产品经理")
    person_list = [person1, person2, person3]

    sorted_persons = bubble_sort(person_list)

    print("按年龄从大到小排序结果：")
    for p in sorted_persons:
        print(f"姓名：{p.name}，年龄：{p.age}")
