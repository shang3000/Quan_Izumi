class Alpha:
    def __init__(self, n):
        self.n = n

    def calculate(self):
        result = 0
        for i in range(1, self.n + 1, 2):
            result += 1 / i
        print(f'{result:.2f}')


alpha = Alpha(95)
alpha.calculate()
