import math


class Shape:
    def __init__(self, name):
        self.name = name

    def calculate_area(self):
        return 0


class Rectangle(Shape):
    def __init__(self, name, length, width):
        super().__init__(name)
        self.length = length
        self.width = width

    def calculate_area(self):
        return self.length * self.width


class Circle(Shape):
    def __init__(self, name, radius):
        super().__init__(name)
        self.radius = radius

    def calculate_area(self):
        return math.pi * self.radius ** 2


if __name__ == "__main__":
    print("--图形面积计算系统--")
    shape_type = input("请输入图形类型：").strip()
    if shape_type == "矩形":
        length = float(input("请输入矩形的长："))
        width = float(input("请输入矩形的宽："))
        rect = Rectangle("矩形", length, width)
        print(f'{rect.name}的面积为{rect.calculate_area():.2f}')
    elif shape_type == "圆形":
        radius = float(input("请输入圆形的半径："))
        circle = Circle("圆形", radius)
        print(f"{circle.name}的面积为：{circle.calculate_area():.2f}")
    else:
        print("输入的图形类型无效！")
