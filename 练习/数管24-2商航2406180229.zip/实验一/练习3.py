class Student:
    def __init__(self, no, name):
        self.no = no
        self.name = name

    def stu_avg(self, score1, score2, score3):
        return (score1 + score2 + score3) / 3


if __name__ == '__main__':
    print("--计算学生平均成绩--")
    try:
        no = input("请输入你的学号：")
        name = input("请输入你的姓名：")
        score1 = int(input("请输入你第一门课程的成绩："))
        score2 = int(input("请输入你第二门课程的成绩："))
        score3 = int(input("请输入你第三门课程的成绩："))
        student = Student(no, name)
        avg = student.stu_avg(score1, score2, score3)
        print(f"学号：{student.no}，姓名：{student.name}，平均成绩：{avg:.2f}")
    except ValueError:
        print("请输入有效的参数")
