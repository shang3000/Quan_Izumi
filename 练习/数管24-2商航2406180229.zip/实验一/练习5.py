class Calculater:
    def __init__(self, a):
        self.a = a

    def calculate(self):
        return self.a


print("---简易计算机系统---")
while True:
    try:
        formula = eval(input("请输入计算公式："))
        calculater = Calculater(formula)
        print(calculater.calculate())
    except NameError:
        print("请输入有效的参数！！")
